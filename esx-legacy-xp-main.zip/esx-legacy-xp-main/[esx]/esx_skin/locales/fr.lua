Locales['fr'] = {
  ['skin_menu'] = 'menu de Skin',
  ['use_rotate_view'] = 'utilisez ~INPUT_VEH_FLY_ROLL_LEFT_ONLY~ et ~INPUT_VEH_FLY_ROLL_RIGHT_ONLY~ pour tourner la vue.',
  ['skin'] = 'changer de skin',
  ['saveskin'] = 'sauvegarder skin dans un fichier',
}
