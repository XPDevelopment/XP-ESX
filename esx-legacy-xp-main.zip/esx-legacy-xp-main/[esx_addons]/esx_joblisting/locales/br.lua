Locales['br'] = {
  ['new_job'] = 'Você agora tem um novo emprego!',
  ['access_job_center'] = 'Pressione ~INPUT_PICKUP~ para acessar a ~b~Lista de Empregos~s~.',
  ['job_center'] = 'Agência de Empregos',
}
