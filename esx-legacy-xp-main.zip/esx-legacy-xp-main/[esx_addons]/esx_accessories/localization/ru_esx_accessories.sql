USE `es_extended`;

INSERT INTO `datastore` (name, label, shared) VALUES
	('user_ears', 'Аксессуары для ушей', 0),
	('user_glasses', 'Очки', 0),
	('user_helmet', 'Шлем', 0),
	('user_mask', 'Маски', 0)
;
