USE `es_extended`;

INSERT INTO `items` (`name`, `label`, `weight`) VALUES
    ('bread', 'Pan', 1),
    ('water', 'Agua', 1)
;
