USE `es_extended`;

INSERT INTO `items` (`name`, `label`, `weight`) VALUES
	('bread', 'Leipä', 1),
	('water', 'Vesi', 1)
;
